package com.example.course;

import java.util.Optional;

public interface CourseService {
	
	public Course getCourseData(int id);

}
