package com.example.course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	CourseRepository repository;
	
	@Override
	public Course getCourseData(int id) {
		return repository.getOne(id);
	}

}
