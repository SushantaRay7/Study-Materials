package com.cg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPOM {
	
	WebDriver driver;
	String uname;
	String password;
	String amount;
	String accountId;
	public LoginPOM(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		getUserField().sendKeys(uname);
	}
	
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		getAmountField().sendKeys(amount);
	}
	
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		getAccountIdField().sendKeys(accountId);
	}
	public void clickAlert() {
		
		driver.switchTo().alert().accept();
	}
	
	public WebElement getAmountField() {
		return driver.findElement(By.name("deposit"));
	}
	public WebElement getUserField() {
		return driver.findElement(By.name("mobile"));
	}
	public WebElement getPasswordField() {
		return driver.findElement(By.name("loginpass"));
	}
	
	public WebElement getAccountIdField() {
		return driver.findElement(By.name("accountId"));
	}
	public void getLoginButton() {
		driver.findElement(By.id("success-button")).click();
	}
	
	public void getShowBalanceButton() {
		driver.findElement(By.id("show")).click();
	}
	public void getDepoButton() {
		driver.findElement(By.id("deposit")).click();
	}
	public void getDepositButton() {
		driver.findElement(By.id("success-button")).click();
	}
	
	public void getWithdrawButton() {
		driver.findElement(By.id("withdraw")).click();
	}
	public void getFundTransferButton() {
		driver.findElement(By.id("transfer")).click();
	}
	
	public void getPrintTransactionButton() {
		driver.findElement(By.id("print")).click();
	}
	
	

}
