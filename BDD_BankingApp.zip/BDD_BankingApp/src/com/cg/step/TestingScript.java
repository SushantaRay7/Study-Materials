package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pom.LoginPOM;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestingScript {

	WebDriver driver;
	LoginPOM pageObject;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\training01\\Downloads\\chromedriver.exe");

	}
	
	@Given("^Open chrome browser and Enter url$")
	public void open_chrome_browser_and_Enter_url() throws Throwable {
		driver=new ChromeDriver(); 
		pageObject=new LoginPOM(driver);
		  driver.manage().window().maximize();
		  driver.get("http://localhost:4200/login"); 
	}

	@When("^User enters valid username \"([^\"]*)\" and valid password: \"([^\"]*)\"$")
	public void user_enters_valid_username_and_valid_password(String uname, String password) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageObject.setUname(uname); 
		pageObject.getPasswordField().sendKeys(password);
	}

	@Then("^user should be able to login$")
	public void user_should_be_able_to_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageObject.getLoginButton();
		Thread.sleep(1000);
		pageObject.clickAlert();
	}
	
	@When("^user clicks the showbutton$")
	public void user_clicks_the_showbutton() throws Throwable {
		Thread.sleep(1000);
		pageObject.getShowBalanceButton();
		
		
	}

	@Then("^user can see balance$")
	public void user_can_see_balance() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		driver.navigate().back();
	}
	
	@When("^user enter the amount \"([^\"]*)\" to deposit$")
	public void user_enter_the_amount_to_deposit(String amount) throws Throwable {
	    Thread.sleep(1000);
	    pageObject.getDepoButton();
	    pageObject.getAmountField().sendKeys(amount);
	}

	@Then("^user can see updated balance$")
	public void user_can_see_updated_balance() throws Throwable {
		pageObject.getDepositButton();
		Thread.sleep(1000);
		pageObject.clickAlert();
	    
	}
	
	@When("^user enter the amount \"([^\"]*)\" to withdraw$")
	public void user_enter_the_amount_to_withdraw(String amount) throws Throwable {
		Thread.sleep(1000);
	    pageObject.getWithdrawButton();
	    pageObject.getAmountField().sendKeys(amount);
	}

	@Then("^user can see updated balance after withdraw$")
	public void user_can_see_updated_balance_after_withdraw() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		  pageObject.getDepositButton(); 
		  Thread.sleep(1000);
		  pageObject.clickAlert();
		 
	}
	
	@When("^user enter accountId \"([^\"]*)\" and amount : \"([^\"]*)\"$")
	public void user_enter_accountId_and_amount(String accountId, String amount) throws Throwable {
		Thread.sleep(1000);
		pageObject.getFundTransferButton();
		pageObject.setAccountId(accountId);
		pageObject.getAmountField().sendKeys(amount);
	}

	@Then("^user can see updated balance after fund transfer$")
	public void user_can_see_updated_balance_after_fund_transfer() throws Throwable {
		pageObject.getDepositButton(); 
		  Thread.sleep(1000);
		  pageObject.clickAlert();
	}
	
	@When("^user clicks the print transaction button$")
	public void user_clicks_the_print_transaction_button() throws Throwable {
		Thread.sleep(1000);
		pageObject.getPrintTransactionButton();
	}

	@Then("^user can see the previous transaction$")
	public void user_can_see_the_previous_transaction() throws Throwable {
		Thread.sleep(1000);
		//pageObject.clickAlert();
		driver.navigate().back();
		driver.get("http://localhost:4200/login");
		pageObject.getCreateAccountButton();
		
	}
	
	@When("^user enter Name \"([^\"]*)\" and  password \"([^\"]*)\"	and confirm password \"([^\"]*)\" and mobile number \"([^\"]*)\" and DOB \"([^\"]*)\" and aadhar number \"([^\"]*)\" and account number \"([^\"]*)\" and pin \"([^\"]*)\"$")
	public void user_enter_Name_and_password_and_confirm_password_and_mobile_number_and_DOB_and_aadhar_number_and_account_number_and_pin(String name, String password, String confirmPassword, String mobile, String dob, String aadhar, String accountNumber, String pin) throws Throwable {
	    Thread.sleep(1000);
	    pageObject.setName(name);
	    pageObject.setCreatePassword(password);
	    pageObject.setConfirmPassword(confirmPassword);
	    pageObject.setMobile(mobile);
	    pageObject.setDob(dob);
	    pageObject.setAadhar(aadhar);
	    pageObject.setAccount(accountNumber);
	    pageObject.setPin(pin);
	    pageObject.getCreateAccountSubmitButton();
	    
	}

	@Then("^user create an account$")
	public void user_create_an_account() throws Throwable {
		Thread.sleep(1000);
		pageObject.clickAlert();
	}
}
