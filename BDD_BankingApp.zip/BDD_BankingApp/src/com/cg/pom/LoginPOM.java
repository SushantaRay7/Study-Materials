package com.cg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPOM {
	
	WebDriver driver;
	String uname;
	String password;
	String amount;
	String accountId;
	String name;
	String createPassword;
	String confirmPassword;
	String mobile;
	String dob;
	String aadhar;
	String account;
	String pin;
	
	public LoginPOM(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		getNameField().sendKeys(name);
	}


	public String getCreatePassword() {
		return createPassword;
	}


	public void setCreatePassword(String createPassword) {
		getCreateAccountPasswordField().sendKeys(createPassword);;
	}


	public String getConfirmPassword() {
		return confirmPassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		getConfirmPasswordField().sendKeys(confirmPassword);;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		getMobileField().sendKeys(mobile);
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		getDOBField().sendKeys(dob);
	}


	public String getAadhar() {
		return aadhar;
	}


	public void setAadhar(String aadhar) {
		getAadharFiled().sendKeys(aadhar);
	}


	public String getAccount() {
		return account;
	}


	public void setAccount(String account) {
		getAccountNumberFiled().sendKeys(account);
	}


	public String getPin() {
		return pin;
	}


	public void setPin(String pin) {
		getPinField().sendKeys(pin);
	}


	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		getUserField().sendKeys(uname);
	}
	
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		getAmountField().sendKeys(amount);
	}
	
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		getAccountIdField().sendKeys(accountId);
	}
	public void clickAlert() {
		
		driver.switchTo().alert().accept();
	}
	
	public WebElement getAmountField() {
		return driver.findElement(By.name("deposit"));
	}
	public WebElement getUserField() {
		return driver.findElement(By.name("mobile"));
	}
	public WebElement getPasswordField() {
		return driver.findElement(By.name("loginpass"));
	}
	
	public WebElement getNameField() {
		return driver.findElement(By.name("name"));
	}
	
	public WebElement getCreateAccountPasswordField() {
		return driver.findElement(By.name("password"));
	}
	
	public WebElement getConfirmPasswordField() {
		return driver.findElement(By.name("cpassword"));
	}
	
	public WebElement getMobileField() {
		return driver.findElement(By.name("mobile"));
	}
	
	public WebElement getDOBField() {
		return driver.findElement(By.name("dob"));
	}
	
	public WebElement getAadharFiled() {
		return driver.findElement(By.name("aadhar"));
	}
	
	public WebElement getAccountNumberFiled() {
		return driver.findElement(By.name("account"));
	}
	public WebElement getPinField() {
		return driver.findElement(By.name("pin"));
	}
	public WebElement getAccountIdField() {
		return driver.findElement(By.name("accountId"));
	}
	public void getLoginButton() {
		driver.findElement(By.id("success-button")).click();
	}
	
	public void getShowBalanceButton() {
		driver.findElement(By.id("show")).click();
	}
	public void getDepoButton() {
		driver.findElement(By.id("deposit")).click();
	}
	public void getDepositButton() {
		driver.findElement(By.id("success-button")).click();
	}
	
	public void getWithdrawButton() {
		driver.findElement(By.id("withdraw")).click();
	}
	public void getFundTransferButton() {
		driver.findElement(By.id("transfer")).click();
	}
	
	public void getPrintTransactionButton() {
		driver.findElement(By.id("print")).click();
	}
	
	public void getCreateAccountButton() {
		driver.findElement(By.id("create")).click();
	}
	
	public void getCreateAccountSubmitButton() {
		driver.findElement(By.id("create")).click();
	}
	
	

}
